package com.sq.recorder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sq.recorder.pojo.po.Article;

public interface ArticleMapper extends BaseMapper<Article> {

}